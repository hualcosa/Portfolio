from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.hooks.base_hook import BaseHook
from airflow.operators.slack_operator import SlackAPIPostOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
"""
Note:
PostgresOperator is used to execute sql statements but cannot return any data.
It will always return None.
This operator can be used to create tables, insert data, etc and for other sql operations that do not need to return any value
"""

import datetime
import pandas as pd
import json

from src import etl


DAG_ID = "data_pipeline"

def init(ti, **context):
    """
    Initialize the job_id and the start_date and end_date.
    """
    start_date = context['dag_run'].conf.get('start_date')
    end_date = context['dag_run'].conf.get('end_date')
    
    if end_date is None:
        end_date = datetime.date.today()
    else:
        end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d").date()
    
    if start_date is None:
        # start_date = end_date - datetime.timedelta(days=30*6)
        start_date = datetime.date(2015, 6, 1)
    else:
        start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d").date()
    assert isinstance(start_date, datetime.date)
    assert isinstance(end_date, datetime.date)
    assert start_date < end_date, "start_date must be less than end_date"
    
    ti.xcom_push(key='end_date', value=str(end_date))
    ti.xcom_push(key='start_date', value=str(start_date))
    
def get_data(ti):
    """
    Extract data from the database and save it to the raw data directory.
    """
    start_date = ti.xcom_pull(key='start_date', task_ids=f'_{DAG_ID}__init_')
    end_date = ti.xcom_pull(key='end_date', task_ids=f'_{DAG_ID}__init_')

    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d").date()
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d").date()
    assert start_date < end_date, "start_date must be less than end_date"
    df = etl.extract_data(start_date=start_date, end_date=end_date)
    ti.xcom_push(key='data', value=df.to_json())

def explore_data(ti):
    """
    Explore data and save the plots to the data directory.
    """
    jf = ti.xcom_pull(key='data', task_ids=f'_{DAG_ID}__get_data_')
    df = pd.DataFrame(json.loads(jf))
    desc = df.describe(include='all')
    print("--- Description of the data ---")
    print(desc.T.to_string())

def create_dag(dag_id):
    with DAG(
        dag_id=dag_id,
        schedule_interval="@daily",
        default_args={
            "owner": "airflow",
            "retries": 0,
            "retry_delay": datetime.timedelta(minutes=1),
            "depends_on_past": False,
            "start_date": datetime.datetime.now() - datetime.timedelta(days=1)
        },
        catchup=False
        
    ) as dag:
        task_start = PythonOperator(task_id=f'_{DAG_ID}__init_', python_callable=init, provide_context=True)
        task_get_data = PythonOperator(task_id=f'_{DAG_ID}__get_data_', python_callable=get_data, provide_context=True)
        task_explore_data = PythonOperator(task_id=f'_{DAG_ID}__explore_data_', python_callable=explore_data, provide_context=True)
        task_end = DummyOperator(task_id="end")

        task_start >> task_get_data >> task_explore_data >> task_end
    return dag

globals()[DAG_ID] = create_dag(DAG_ID)