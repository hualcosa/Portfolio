import torch
import torch.nn as nn
import torchvision.models as models


class EncoderCNN(nn.Module):
    def __init__(self, embed_size):
        super(EncoderCNN, self).__init__()
        resnet = models.resnet50(pretrained=True)
        for param in resnet.parameters():
            param.requires_grad_(False)
        
        modules = list(resnet.children())[:-1]
        self.resnet = nn.Sequential(*modules)
        self.embed = nn.Linear(resnet.fc.in_features, embed_size)

    def forward(self, images):
        features = self.resnet(images)
        features = features.view(features.size(0), -1)
        features = self.embed(features)
        return features
    
    

class DecoderRNN(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab_size, num_layers=1):
        super().__init__()
        self.lstm = nn.LSTM(input_size=embed_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, vocab_size)
        self.word_embeddings = nn.Embedding(vocab_size, embed_size)
        
        # initialize weights
        self.init_weights()
    
    def init_weights(self):
        nn.init.xavier_uniform_(self.fc.weight)
        nn.init.xavier_uniform_(self.word_embeddings.weight)
        
    def forward(self, features, captions):
        # removing end token from captions
        captions = captions[:,:-1]
        # embedding captions
        captions_embed = self.word_embeddings(captions)
        # concatenating parts to form the input
        inputs = torch.cat((features.unsqueeze(1), captions_embed), dim=1)
        outputs, _ = self.lstm(inputs)
        outputs = self.fc(outputs)
        return outputs

    def sample(self, inputs, states=None, max_len=20):
        " accepts pre-processed image tensor (inputs) and returns predicted sentence (list of tensor ids of length max_len) "
        predictions = []
        for i in range(max_len):
            outputs, states = self.lstm(inputs, states)
            outputs = self.fc(outputs)
            token = torch.argmax(outputs.squeeze(1))
            # appending token to predictions
            predictions.append(token.item())
            # if we find the end token, break the process
            if token.item() == 1:
                break
            # embed token and reshape, so the embedding has the shape expected by the LSTM Cell
            inputs = self.word_embeddings(token).view(1,1,-1)
         
        return predictions