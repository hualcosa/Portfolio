import os

# input folder in reference to base folder
input_folder = os.path.join("../", "Input")

# output folder in reference to base folder
output_folder = os.path.join("../", "Output")

