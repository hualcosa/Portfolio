#  Topics to be discussed

  1) BackGround Subtraction
  2) CamShift
  3) MeanShift
  4) Cascade Classifier # (already discussed OpenCV Project for Beginners to Learn Computer Vision Basics)
  5) Color Quantization
  6) Lucas Kanade Optical Flow
  7) Dense Optical Flow
  8) Epipolar Geometry
  9) Depth Map for Stereo
  10) HDR Images
  11) Image De-noising
